package mvc.employee.view;

import javafx.fxml.FXML;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;
import javafx.stage.WindowEvent;
import mvc.employee.ViewLoader;

public class MainController {

	private Stage primaryStage;
	ViewLoader<AnchorPane, EmployeeController> fxmLayoutEmp;
	ViewLoader<AnchorPane, DepartmentController> fxmLayoutDep;
	ViewLoader<AnchorPane, JobController> fxmLayoutJob;

	public void setStage(Stage primaryStage) {
		this.primaryStage = primaryStage;
	}

	public void setEmployeeFXML(ViewLoader<AnchorPane, EmployeeController> fxmLayoutEmp) {
		this.fxmLayoutEmp = fxmLayoutEmp;
	}

	public void setDepartmentFXML(ViewLoader<AnchorPane, DepartmentController> fxmLayoutDep) {
		this.fxmLayoutDep = fxmLayoutDep;
	}

	public void setJobFXML(ViewLoader<AnchorPane, JobController> fxmLayoutJob) {
		this.fxmLayoutJob = fxmLayoutJob;
	}

	@FXML
	private void menuItem_About() {
		AlertBox.showAndWait(AlertType.INFORMATION, "O aplikacji", "Pracownicy");
	}

	@FXML
	private void menuItem_Exit() {
		primaryStage.fireEvent(new WindowEvent(primaryStage, WindowEvent.WINDOW_CLOSE_REQUEST));
	}
}