
package mvc.employee.view;

import java.time.LocalDate;

import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import mvc.employee.model.Employee;
import mvc.employee.model.Job;

public class JobController {

	// TableView, TableColumn
	@FXML
	private TableView<Job> jobTable;
	@FXML
	private TableColumn<Job, String> jobIdColumn;
	@FXML
	private TableColumn<Job, String> jobTitleColumn;
	@FXML
	private TableColumn<Job, Integer> minSalaryColumn;
	@FXML
	private TableColumn<Job, Integer> maxSalaryColumn;

	// Label
	@FXML
	private Label jobIdLabel;
	@FXML
	private Label jobTitleLabel;
	@FXML
	private Label minSalaryLabel;
	@FXML
	private Label maxSalaryLabel;

	public void setJobs(ObservableList<Job> olJobs) {

		jobTable.getItems().clear();
		jobTable.setItems(olJobs);

		if (!jobTable.getItems().isEmpty())
			jobTable.getSelectionModel().select(0);
	}

	@FXML
	private void initialize() {
		jobTable.setTableMenuButtonVisible(true);

		jobIdColumn.setCellValueFactory(cellData -> cellData.getValue().jobIdProperty());
		jobTitleColumn.setCellValueFactory(cellData -> cellData.getValue().jobTitleProperty());
		minSalaryColumn.setCellValueFactory(cellData -> cellData.getValue().minSalaryProperty().asObject());
		maxSalaryColumn.setCellValueFactory(cellData -> cellData.getValue().maxSalaryProperty().asObject());

		refreshJob(null);

		jobTable.getSelectionModel().selectedItemProperty()
				.addListener((observable, oldValue, newValue) -> refreshJob(newValue));
	}

	private void refreshJob(Job job) {
		if (job != null) {

			jobIdLabel.setText(job.getjobId());
			jobTitleLabel.setText(job.getjobTitle());

			minSalaryLabel.setText(Integer.toString(job.getminSalary()));
			maxSalaryLabel.setText(Integer.toString(job.getmaxSalary()));

		} else {
			jobIdLabel.setText("");
			jobTitleLabel.setText("");
			minSalaryLabel.setText("");
			maxSalaryLabel.setText("");

		}
	}

	@FXML
	private void deleteEmployee() {
		int selIdx = jobTable.getSelectionModel().getSelectedIndex();
		if (selIdx >= 0)
			jobTable.getItems().remove(selIdx);
	}

}