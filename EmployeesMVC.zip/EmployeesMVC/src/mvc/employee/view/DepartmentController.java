
package mvc.employee.view;

import java.time.LocalDate;

import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import mvc.employee.model.Department;
import mvc.employee.model.Employee;
import mvc.employee.model.Job;

public class DepartmentController {

	// TableView, TableColumn
	@FXML
	private TableView<Department> departmentTable;
	@FXML
	private TableColumn<Department, Integer> departmentIdColumn;
	@FXML
	private TableColumn<Department, String> departmentNameColumn;
	@FXML
	private TableColumn<Department, Integer> managerIdColumn;
	@FXML
	private TableColumn<Department, Integer> locationIdColumn;

	// Label
	@FXML
	private Label departmentIdLabel;
	@FXML
	private Label departmentNameLabel;
	@FXML
	private Label managerIdLabel;
	@FXML
	private Label locationIdLabel;

	public void setDepartments(ObservableList<Department> olDepartmens) {

		departmentTable.getItems().clear();
		departmentTable.setItems(olDepartmens);

		if (!departmentTable.getItems().isEmpty())
			departmentTable.getSelectionModel().select(0);
	}

	@FXML
	private void initialize() {
		departmentTable.setTableMenuButtonVisible(true);

		departmentIdColumn.setCellValueFactory(cellData -> cellData.getValue().departmentIdProperty().asObject());
		departmentNameColumn.setCellValueFactory(cellData -> cellData.getValue().departmentNameProperty());
		managerIdColumn.setCellValueFactory(cellData -> cellData.getValue().managerIdProperty().asObject());
		locationIdColumn.setCellValueFactory(cellData -> cellData.getValue().locationIdProperty().asObject());

		refreshDepartment(null);

		departmentTable.getSelectionModel().selectedItemProperty()
				.addListener((observable, oldValue, newValue) -> refreshDepartment(newValue));
	}

	private void refreshDepartment(Department dep) {
		if (dep != null) {

			departmentIdLabel.setText(Integer.toString(dep.getdepartmentId()));
			departmentNameLabel.setText(dep.getdepartmentName());
			managerIdLabel.setText(Integer.toString(dep.getmanagerId()));
			locationIdLabel.setText(Integer.toString(dep.getlocationId()));

		} else {
			departmentIdLabel.setText("");
			departmentNameLabel.setText("");
			managerIdLabel.setText("");
			locationIdLabel.setText("");

		}
	}

	@FXML
	private void deleteEmployee() {
		int selIdx = departmentTable.getSelectionModel().getSelectedIndex();
		if (selIdx >= 0)
			departmentTable.getItems().remove(selIdx);
	}

}