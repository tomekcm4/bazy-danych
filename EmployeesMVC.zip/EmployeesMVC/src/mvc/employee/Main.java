package mvc.employee;

import java.util.Optional;

import javafx.application.Application;
import javafx.stage.Stage;
import javafx.stage.WindowEvent;
import mvc.employee.model.dal.DepartmentsDAL;
import mvc.employee.model.dal.EmployeesDAL;
import mvc.employee.model.dal.JobsDAL;
import mvc.employee.model.dal.OraConn;
import mvc.employee.view.AlertBox;
import mvc.employee.view.DepartmentController;
import mvc.employee.view.EmployeeController;
import mvc.employee.view.JobController;
import mvc.employee.view.MainController;
import javafx.scene.Scene;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.ButtonType;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.BorderPane;

public class Main extends Application {

	public static void main(String[] args) {
		launch(args);
	}

	@Override
	public void start(Stage primaryStage) {
		try {
			if (OraDbConnect() > 0)
				return;

			ViewLoader<BorderPane, Object> viewLoader = new ViewLoader<BorderPane, Object>("view/Main.fxml");
			BorderPane borderPane = viewLoader.getLayout();

			Scene scene = new Scene(borderPane);
			primaryStage.setScene(scene);
			primaryStage.setTitle("Pracownicy");
			primaryStage.setOnHiding(e -> primaryStage_Hiding(e));
			primaryStage.setOnCloseRequest(e -> primaryStage_CloseRequest(e));
			primaryStage.show();

			ViewLoader<AnchorPane, EmployeeController> viewLoaderEmp = new ViewLoader<AnchorPane, EmployeeController>(
					"view/EmployeeData.fxml");
			AnchorPane anchorPaneEmp = viewLoaderEmp.getLayout();
			borderPane.setCenter(anchorPaneEmp);

			ViewLoader<AnchorPane, DepartmentController> viewLoaderDep = new ViewLoader<AnchorPane, DepartmentController>(
					"view/EmployeeData.fxml");
			AnchorPane anchorPaneDep = viewLoaderEmp.getLayout();
			borderPane.setCenter(anchorPaneDep);

			ViewLoader<AnchorPane, JobController> viewLoaderJob = new ViewLoader<AnchorPane, JobController>(
					"view/EmployeeData.fxml");
			AnchorPane anchorPaneJob = viewLoaderJob.getLayout();
			borderPane.setCenter(anchorPaneJob);

			((MainController) viewLoader.getController()).setStage(primaryStage);

			EmployeeController empControler = viewLoaderEmp.getController();
			((MainController) viewLoader.getController()).setStage(primaryStage);
			((MainController) viewLoader.getController()).setEmployeeFXML(viewLoaderEmp);
			empControler.setEmployees(new EmployeesDAL().getEmployees());

			DepartmentController depControler = viewLoaderDep.getController();
			((MainController) viewLoader.getController()).setStage(primaryStage);
			((MainController) viewLoader.getController()).setDepartmentFXML(viewLoaderDep);
			depControler.setDepartments(new DepartmentsDAL().getDepartments());

			JobController jobControler = viewLoaderJob.getController();
			((MainController) viewLoader.getController()).setStage(primaryStage);
			((MainController) viewLoader.getController()).setJobFXML(viewLoaderJob);
			jobControler.setJobs(new JobsDAL().getJobs());

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	void primaryStage_Hiding(WindowEvent e) {
		OraConn.close();
	}

	void primaryStage_CloseRequest(WindowEvent e) {
		Optional<ButtonType> result = AlertBox.showAndWait(AlertType.CONFIRMATION, "Ko�czenie pracy",
				"Czy chcesz zamkn�� aplikacj�?");
		if (result.orElse(ButtonType.CANCEL) != ButtonType.OK)
			e.consume();
	}

	int OraDbConnect() {
		int ret = OraConn.open("jdbc:oracle:thin:@ora3.elka.pw.edu.pl:1521:ora3inf", "XTEMP12", "xtemp12");
		if (ret > 0) {
			AlertBox.showAndWait(AlertType.ERROR, "Nawi�zanie po��czenia z baz� danych",
					"Nieprawid�owy u�ytkownik lub has�o.\n" + "[" + OraConn.getErr() + "] " + OraConn.getErrMsg());
		}
		return ret;
	}

}
