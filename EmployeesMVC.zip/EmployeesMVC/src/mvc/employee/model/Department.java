package mvc.employee.model;

import java.time.LocalDate;

import javafx.beans.property.IntegerProperty;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;

public class Department {

	private IntegerProperty departmentId;
	private StringProperty departmentName;
	private IntegerProperty managerId;
	private IntegerProperty locationId;

	public Department() {
		departmentId = new SimpleIntegerProperty(0);
		departmentName = new SimpleStringProperty("");
		managerId = new SimpleIntegerProperty(0);
		locationId = new SimpleIntegerProperty(0);

	}

	public int getdepartmentId() {
		return this.departmentId.get();
	}

	public void setdepartmentId(int jobId) {
		this.departmentId.set(jobId);
	}

	public IntegerProperty departmentIdProperty() {
		return this.departmentId;
	}

	public String getdepartmentName() {
		return this.departmentName.get();
	}

	public void setdepartmentName(String departmentName) {
		this.departmentName.set(departmentName);
	}

	public StringProperty departmentNameProperty() {
		return this.departmentName;
	}

	public int getmanagerId() {
		return this.managerId.get();
	}

	public void setmanagerId(int managerId) {
		this.managerId.set(managerId);
	}

	public IntegerProperty managerIdProperty() {
		return this.managerId;
	}

	public int getlocationId() {
		return this.locationId.get();
	}

	public void setlocationId(int locationId) {
		this.locationId.set(locationId);
	}

	public IntegerProperty locationIdProperty() {
		return this.locationId;
	}

}
