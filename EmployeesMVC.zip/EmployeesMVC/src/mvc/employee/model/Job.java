package mvc.employee.model;

import java.time.LocalDate;

import javafx.beans.property.IntegerProperty;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleObjectProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;

public class Job {

	private StringProperty jobId;
	private StringProperty jobTitle;

	private IntegerProperty minSalary;
	private IntegerProperty maxSalary;

	public Job() {

		jobId = new SimpleStringProperty("");
		jobTitle = new SimpleStringProperty("");
		minSalary = new SimpleIntegerProperty(0);
		maxSalary = new SimpleIntegerProperty(0);

	}

	public Job(String jobId) {
		this();
		setjobId(jobId);
	}

	public String getjobId() {
		return this.jobId.get();
	}

	public void setjobId(String jobId) {
		this.jobId.set(jobId);
	}

	public StringProperty jobIdProperty() {
		return this.jobId;
	}

	public String getjobTitle() {
		return this.jobTitle.get();
	}

	public void setjobTitle(String jobTitle) {
		this.jobTitle.set(jobTitle);
	}

	public StringProperty jobTitleProperty() {
		return this.jobTitle;
	}

	public int getminSalary() {
		return this.minSalary.get();
	}

	public void setminSalary(int minSalary) {
		this.minSalary.set(minSalary);
	}

	public IntegerProperty minSalaryProperty() {
		return this.minSalary;
	}

	public int getmaxSalary() {
		return this.maxSalary.get();
	}

	public void setmaxSalary(int maxSalary) {
		this.maxSalary.set(maxSalary);
	}

	public IntegerProperty maxSalaryProperty() {
		return this.maxSalary;
	}

	@Override
	public String toString() {
		return jobId + " " + jobTitle;
	}

}

// String jobId;
// String jobTitle;
// int minSalary;
// int maxSalary;

/*
 * 
 * public Job() { } public Job(String jobId) {this.jobId = jobId; }
 * 
 * public String getJobId() { return jobId; } public void setJobId(String jobId)
 * { this.jobId = jobId; }
 * 
 * public String getJobTitle() { return jobTitle; } public void
 * setJobTitle(String jobTitle) { this.jobTitle = jobTitle; }
 * 
 * public int getMinSalary() { return minSalary; } public void setMinSalary(int
 * minSalary) { this.minSalary = minSalary; }
 * 
 * public int getMaxSalary() { return maxSalary; } public void setMaxSalary(int
 * maxSalary) { this.maxSalary = maxSalary; }
 * 
 * @Override public String toString() { return jobTitle;
 * 
 * }
 * 
 * }
 * 
 */
