package mvc.employee.model;

import java.time.LocalDate;

import javafx.beans.property.IntegerProperty;
import javafx.beans.property.ObjectProperty;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleObjectProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;

public class Employee {

	private IntegerProperty employeeId;
	private StringProperty firstName;
	private StringProperty lastName;
	private StringProperty email;
	private StringProperty phoneName;
	private ObjectProperty<LocalDate> hireDate;
	private StringProperty jobId;
	private IntegerProperty salary;
	private IntegerProperty managerId;
	private IntegerProperty departmentId;

	public Employee() {
		employeeId = new SimpleIntegerProperty(0);
		firstName = new SimpleStringProperty("");
		lastName = new SimpleStringProperty("");
		email = new SimpleStringProperty("");
		phoneName = new SimpleStringProperty("");
		hireDate = new SimpleObjectProperty<LocalDate>(LocalDate.now());
		jobId = new SimpleStringProperty("");
		salary = new SimpleIntegerProperty(0);
		managerId = new SimpleIntegerProperty(0);
		departmentId = new SimpleIntegerProperty(0);

	}

	public Employee(int employeeId) {
		this();
		setEmployeeId(employeeId);
	}

	public int getEmployeeId() {
		return this.employeeId.get();
	}

	public void setEmployeeId(int employeeId) {
		this.employeeId.set(employeeId);
	}

	public IntegerProperty employeeIdProperty() {
		return this.employeeId;
	}

	public String getFirstName() {
		return this.firstName.get();
	}

	public void setFirstName(String firstName) {
		this.firstName.set(firstName);
	}

	public StringProperty firstNameProperty() {
		return this.firstName;
	}

	public String getLastName() {
		return this.lastName.get();
	}

	public void setLastName(String lastName) {
		this.lastName.set(lastName);
	}

	public StringProperty lastNameProperty() {
		return this.lastName;
	}

	public String getEmail() {
		return this.email.get();
	}

	public void setEmail(String email) {
		this.email.set(email);
	}

	public StringProperty emailProperty() {
		return this.email;
	}

	public String getPhoneName() {
		return this.phoneName.get();
	}

	public void setPhoneName(String phoneName) {
		this.phoneName.set(phoneName);
	}

	public StringProperty phoneNameProperty() {
		return this.phoneName;
	}

	public LocalDate getHireDate() {
		return this.hireDate.get();
	}

	public void setHireDate(LocalDate hireDate) {
		this.hireDate.set(hireDate);
	}

	public ObjectProperty<LocalDate> hireDateProperty() {
		return this.hireDate;
	}

	public String getJobId() {
		return this.jobId.get();
	}

	public void setJobId(String jobId) {
		this.jobId.set(jobId);
	}

	public StringProperty jobIdProperty() {
		return this.jobId;
	}

	public int getSalary() {
		return this.salary.get();
	}

	public void setSalary(int salary) {
		this.salary.set(salary);
	}

	public IntegerProperty salaryProperty() {
		return this.salary;
	}

	public int getManagerId() {
		return this.managerId.get();
	}

	public void setManagerId(int managerId) {
		this.managerId.set(managerId);
	}

	public IntegerProperty managerIdProperty() {
		return this.managerId;
	}

	public int getDepartmentId() {
		return this.departmentId.get();
	}

	public void setDepartmentId(int departmentId) {
		this.departmentId.set(departmentId);
	}

	public IntegerProperty departmentIdProperty() {
		return this.departmentId;
	}

	@Override
	public String toString() {
		return lastName + " " + firstName;
	}

}
