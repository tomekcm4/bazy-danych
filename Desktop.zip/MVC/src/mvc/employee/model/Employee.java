package mvc.employee.model;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import javafx.beans.property.*;

public class Employee {

	private IntegerProperty employeeId;
	private StringProperty firstName;
	private StringProperty lastName;
	private StringProperty email;
	private StringProperty phoneName;
	private ObjectProperty<LocalDate> hireDate;
	private StringProperty jobId;
	private IntegerProperty salary;
	private IntegerProperty managerId;
	private IntegerProperty departmentId;

	public Employee() {

		employeeId = new SimpleIntegerProperty(0);
		firstName = new SimpleStringProperty("");
		lastName = new SimpleStringProperty("");
		email = new SimpleStringProperty("");
		phoneName = new SimpleStringProperty("");
		hireDate = new SimpleObjectProperty<LocalDate>(LocalDate.now());
		jobId = new SimpleStringProperty("");
		salary = new SimpleIntegerProperty(0);
		managerId = new SimpleIntegerProperty(0);
		departmentId = new SimpleIntegerProperty(0);

	}

	public Employee(int employeeId) {
		this();
		this.employeeId.set(employeeId);
	}

	public int getEmployeeId() {
		return this.employeeId.get();
	}

	public void setEmployeeId(int employeeId) {
		this.employeeId.set(employeeId);
	}

	public IntegerProperty employeeIdProperty() {
		return employeeId;
	}

	public String getFirstName() {
		return firstName.get();
	}

	public void setFirstName(String firstName) {
		this.firstName.set(firstName);

	}

	public StringProperty firstNameProperty() {
		return firstName;
	}


	public String getLastName() {
		return lastName.get();
	}

	public void setLastName(String firstName) {
		this.lastName.set(firstName);

	}

	public StringProperty lastNameProperty() {
		return lastName;
	}
	
	public String getEmail() {
		return email.get();
	}

	public void setEmail(String firstName) {
		this.email.set(firstName);

	}

	public StringProperty emailProperty() {
		return email;
	}
	
	public String getPhoneName() {
		return phoneName.get();
	}

	public void setPhoneName(String phoneName) {
		this.email.set(phoneName);

	}

	public StringProperty phoneNameProperty() {
		return email;
	}
	
	public String getJobId() {
		return jobId.get();
	}

	public void setJobId(String jobId) {
		this.email.set(jobId);

	}

	public StringProperty jobIdProperty() {
		return jobId;
	}
	
	public int getSalary() {
		return this.salary.get();
	}

	public void setSalary(int salary) {
		this.salary.set(salary);
	}

	public IntegerProperty salaryProperty() {
		return salary;
	}
	
	
	public int getManagerId() {
		return this.employeeId.get();
	}

	public void setManagerId(int managerId) {
		this.managerId.set(managerId);
	}

	public IntegerProperty managerIdProperty() {
		return managerId;
	}
	
	public int getDepartmentId() {
		return this.employeeId.get();
	}

	public void setDepartmentId(int departmentId) {
		this.departmentId.set(departmentId);
	}

	public IntegerProperty departmentIdProperty() {
		return departmentId;
	}
	
	public LocalDate getHireDate(){
		return this.hireDate.get();
		}
	
	public void setHireDate(LocalDate hireDate){
		this.hireDate.set(hireDate);
		}
	
	public ObjectProperty<LocalDate> hireDateProperty(){
		return hireDate;
	}
	
	
	
}